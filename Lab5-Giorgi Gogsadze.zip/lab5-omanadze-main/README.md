# lab5
1. დააყენეთ laravel installer-ი composer-ის გამოყენებით (composer global require laravel/installer)
2. შექმენით ახალი პროექტი laravel new my-app ბრძანების გამოყენებით
3. გადადით ახალ პროექტის ფოლდერში და გაუშვით პროექტი php artisan serve ბრძანების გამოყენებით
